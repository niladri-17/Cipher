import Chat from "../models/chat.model.js";
import User from "../models/user.model.js";
import Message from "../models/message.model.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import { ApiError } from "../utils/ApiError.js";

const getAllChats = asyncHandler(async (req, res) => {
  const userId = req.user._id; // Authenticated user's ID

  // ✅ Fetch chats where the user is a participant
  const chats = await Chat.find({ members: userId })
    .populate("members", "fullName email profilePic status")
    .populate({
      path: "lastMessage",
      select: "sender text createdAt",
      populate: {
        path: "sender",
        select: "fullName profilePic",
      },
    })
    .sort({ updatedAt: -1 });

  return res.status(200).json(new ApiResponse(200, chats, "Chats fetched"));
});

const searchAllChats = asyncHandler(async (req, res) => {
  const { query } = req.query;
  const currentUserId = req.user._id;

  if (!query) {
    throw new ApiError(400, "Search query is required");
  }

  // Get chats where user is a member
  const chats = await Chat.find({
    members: currentUserId,
    $or: [
      { groupName: { $regex: query, $options: "i" } },
      { isGroup: false } // Include non-group chats
    ]
  })
  .populate("members", "fullName email")
  .populate("lastMessage")
  .lean();

  // Get users who don't have any chats with current user
  const usersWithNoChats = await User.aggregate([
    // Find all users except current user
    {
      $match: {
        _id: { $ne: currentUserId },
        fullName: { $regex: query, $options: "i" }
      }
    },
    // Look for chats with these users
    {
      $lookup: {
        from: "chats",
        let: { userId: "$_id" },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $in: ["$$userId", "$members"] },
                  { $in: [currentUserId, "$members"] }
                ]
              }
            }
          }
        ],
        as: "existingChats"
      }
    },
    // Only keep users with no chats
    {
      $match: {
        existingChats: { $size: 0 }
      }
    },
    // Keep relevant fields
    {
      $project: {
        _id: 1,
        fullName: 1,
        email: 1
      }
    }
  ]);

  // Get messages containing the query text
  const messages = await Message.find({
    chatId: { $in: chats.map(chat => chat._id) },
    text: { $regex: query, $options: "i" },
    isDeleted: false,
    isVisible: true
  })
  .populate("chatId", "groupName members")
  .populate("sender", "fullName email")
  .sort({ createdAt: -1 })
  .lean();

  const data = {
    chats: chats || [],
    users: usersWithNoChats || [],
    messages: messages || []
  };

  return res.status(200).json(
    new ApiResponse(200, data, "Search results fetched successfully")
  );
});

// Start Private chat
const startPrivateChat = asyncHandler(async (req, res) => {
  const { userId } = req.body;
  const currentUserId = req.user._id; // From authMiddleware

  if (userId) {
    const existingChat = await Chat.findOne({
      isGroup: false,
      members: { $all: [currentUserId, userId] },
    });

    if (existingChat) {
      return res
        .status(200)
        .json(new ApiResponse(200, existingChat, "Chat exists"));
    }

    const newChat = await Chat.create({
      members: [currentUserId, userId],
      isGroup: false,
    });

    return res.status(201).json(new ApiResponse(201, newChat, "Chat started"));
  }

  throw new ApiError(400, "Invalid request");
});

// start Group chat
const startGroupChat = asyncHandler(async (req, res) => {
  const { userIds, groupName } = req.body;
  const currentUserId = req.user._id; // From authMiddleware

  // 🟢 2️⃣ Group Chat
  if (userIds && userIds.length > 0) {
    if (!groupName) {
      throw new ApiError(400, "Group name is required");
    }

    // Ensure the current user is part of the group
    if (!userIds.includes(currentUserId.toString())) {
      userIds.push(currentUserId.toString());
    }

    const newGroup = await Chat.create({
      members: userIds,
      isGroup: true,
      groupName,
      admins: currentUserId,
      createdBy: currentUserId,
    });

    return res
      .status(201)
      .json(new ApiResponse(201, newGroup, "Group created"));
  }

  throw new ApiError(400, "Invalid request");
});

// exports.deleteChat = (req, res) => {};

export { getAllChats, searchAllChats, startPrivateChat, startGroupChat };
