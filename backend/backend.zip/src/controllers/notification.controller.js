exports.getNotifications = (req, res) => {};
exports.markNotificationAsRead = (req, res) => {};
exports.deleteNotification = (req, res) => {};
